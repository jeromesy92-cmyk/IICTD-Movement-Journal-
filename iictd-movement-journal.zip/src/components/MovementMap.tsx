import React, { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { UserData } from '../App';

// Fix for default marker icon issue with Webpack
delete L.Icon.Default.prototype._getIconUrl;

L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
});

interface MovementMapProps {
  user: UserData;
}

interface Movement {
  id: number;
  user_id: number;
  type: string;
  status: string;
  start_location: { lat: number; lng: number; name: string };
  end_location: { lat: number; lng: number; name: string };
  start_time: string;
  end_time: string;
}

const MovementMap: React.FC<MovementMapProps> = ({ user }) => {
  const [movements, setMovements] = useState<Movement[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchMovements = async () => {
      try {
        // Simulate fetching data
        const mockMovements: Movement[] = [
          {
            id: 1,
            user_id: user.id,
            type: 'Field Visit',
            status: 'Completed',
            start_location: { lat: 34.0522, lng: -118.2437, name: 'Los Angeles' },
            end_location: { lat: 34.0522, lng: -118.2437, name: 'Los Angeles' },
            start_time: '2023-01-01T09:00:00Z',
            end_time: '2023-01-01T17:00:00Z',
          },
          {
            id: 2,
            user_id: user.id,
            type: 'Site Inspection',
            status: 'Completed',
            start_location: { lat: 34.0522, lng: -118.2437, name: 'Los Angeles' },
            end_location: { lat: 34.0522, lng: -118.2437, name: 'Los Angeles' },
            start_time: '2023-01-05T10:00:00Z',
            end_time: '2023-01-05T14:00:00Z',
          },
          {
            id: 3,
            user_id: user.id,
            type: 'Delivery',
            status: 'Completed',
            start_location: { lat: 34.0522, lng: -118.2437, name: 'Los Angeles' },
            end_location: { lat: 34.0522, lng: -118.2437, name: 'Los Angeles' },
            start_time: '2023-01-10T11:00:00Z',
            end_time: '2023-01-10T12:00:00Z',
          },
        ];
        setMovements(mockMovements);
      } catch (err) {
        setError('Failed to fetch movements.');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchMovements();
  }, [user.id]);

  if (loading) {
    return <div className="p-8 text-center">Loading map data...</div>;
  }

  if (error) {
    return <div className="p-8 text-center text-red-500">Error: {error}</div>;
  }

  const center = movements.length > 0 
    ? [movements[0].start_location.lat, movements[0].start_location.lng] 
    : [34.0522, -118.2437]; // Default to Los Angeles if no movements

  return (
    <div className="flex-1 h-full w-full">
      <MapContainer center={center as [number, number]} zoom={13} className="h-full w-full rounded-xl shadow-lg">
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
        />
        {movements.map((movement) => (
          <React.Fragment key={movement.id}>
            <Marker position={[movement.start_location.lat, movement.start_location.lng]}>
              <Popup>
                <b>Start:</b> {movement.start_location.name}<br/>
                Type: {movement.type}<br/>
                Status: {movement.status}<br/>
                Time: {new Date(movement.start_time).toLocaleString()}
              </Popup>
            </Marker>
            {movement.end_location && (
              <Marker position={[movement.end_location.lat, movement.end_location.lng]}>
                <Popup>
                  <b>End:</b> {movement.end_location.name}<br/>
                  Type: {movement.type}<br/>
                  Status: {movement.status}<br/>
                  Time: {new Date(movement.end_time).toLocaleString()}
                </Popup>
              </Marker>
            )}
          </React.Fragment>
        ))}
      </MapContainer>
    </div>
  );
};

export default MovementMap;
