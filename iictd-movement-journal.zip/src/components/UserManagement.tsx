import React, { useState, useEffect } from 'react';
import { 
  Users, 
  UserPlus, 
  Search, 
  Shield, 
  MoreVertical, 
  Edit2, 
  Trash2, 
  CheckCircle2, 
  XCircle,
  Key,
  MapPin,
  Briefcase,
  X,
  ChevronDown
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'react-hot-toast';
import { UserData } from '../App';
import QRCode from 'react-qr-code';

const ALL_DISTRICTS = Array.from({ length: 33 }, (_, i) => `District ${i + 1}`);

export default function UserManagement({ user }: { user: UserData }) {
  const [users, setUsers] = useState<UserData[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('All');
  const [statusFilter, setStatusFilter] = useState('All');
  const [divisionFilter, setDivisionFilter] = useState('All');
  const [baseOfficeFilter, setBaseOfficeFilter] = useState('All');
  const [selectedUsers, setSelectedUsers] = useState<number[]>([]);
  const [userToDelete, setUserToDelete] = useState<number | null>(null);
  const [viewingUser, setViewingUser] = useState<UserData | null>(null);

  const [editingUser, setEditingUser] = useState<UserData | null>(null);
  const [formData, setFormData] = useState({
    id_number: '',
    username: '',
    password: '',
    full_name: '',
    division: '',
    district: [] as string[], // Changed to array
    base_office: '',
    role: 'Field Engineer' as any,
    supervisor_id: ''
  });

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleBulkAction = async (action: 'activate' | 'deactivate' | 'delete') => {
    if (selectedUsers.length === 0) return;

    // Prevent non-administrators from modifying administrators
    const usersToModify = users.filter(u => selectedUsers.includes(u.id));
    const hasAdmin = usersToModify.some(u => u.role === 'Administrator');
    if (hasAdmin && user.role !== 'Administrator') {
      toast.error('You do not have permission to modify Administrator accounts.');
      return;
    }

    if (action === 'delete') {
      if (!window.confirm(`Are you sure you want to delete ${selectedUsers.length} users?`)) return;
      
      try {
        const response = await fetch('/api/users/bulk', {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ids: selectedUsers })
        });
        
        if (response.ok) {
          toast.success(`${selectedUsers.length} users deleted successfully`);
          setSelectedUsers([]);
          fetchUsers();
        } else {
          const data = await response.json();
          toast.error(data.message || 'Failed to delete users');
        }
      } catch (error) {
        toast.error('Connection error');
      }
    } else {
      const status = action === 'activate' ? 'active' : 'inactive';
      try {
        const response = await fetch('/api/users/bulk/status', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ids: selectedUsers, status })
        });
        
        if (response.ok) {
          toast.success(`${selectedUsers.length} users ${status === 'active' ? 'activated' : 'deactivated'} successfully`);
          setSelectedUsers([]);
          fetchUsers();
        } else {
          const data = await response.json();
          toast.error(data.message || `Failed to ${action} users`);
        }
      } catch (error) {
        toast.error('Connection error');
      }
    }
  };

  const toggleSelectAll = () => {
    if (selectedUsers.length === filteredUsers.length) {
      setSelectedUsers([]);
    } else {
      // Don't select administrators if the current user is not an administrator
      const selectableUsers = user.role === 'Administrator' 
        ? filteredUsers 
        : filteredUsers.filter(u => u.role !== 'Administrator');
      setSelectedUsers(selectableUsers.map(u => u.id));
    }
  };

  const toggleSelectUser = (id: number, role: string) => {
    if (role === 'Administrator' && user.role !== 'Administrator') {
      toast.error('You do not have permission to modify Administrator accounts.');
      return;
    }
    
    if (selectedUsers.includes(id)) {
      setSelectedUsers(selectedUsers.filter(userId => userId !== id));
    } else {
      setSelectedUsers([...selectedUsers, id]);
    }
  };

  const fetchUsers = () => {
    setLoading(true);
    fetch('/api/users')
      .then(res => res.json())
      .then(data => {
        setUsers(data);
        setLoading(false);
      });
  };

  const handleEdit = (user: UserData) => {
    setEditingUser(user);
    setFormData({
      id_number: user.id_number || '',
      username: user.username || '',
      password: '', // Leave empty unless they want to change it
      full_name: user.full_name || '',
      division: user.division || 'N/A',
      district: Array.isArray(user.district) ? user.district : (user.district ? [user.district] : []), // Ensure district is an array
      base_office: user.base_office || 'N/A',
      role: user.role || 'Field Engineer',
      supervisor_id: user.supervisor_id?.toString() || ''
    });
    setShowForm(true);
  };

  const resetForm = () => {
    setEditingUser(null);
    setShowForm(false);
    setFormData({
      id_number: '',
      username: '',
      password: '',
      full_name: '',
      division: 'N/A',
      district: [], // Changed to empty array
      base_office: 'N/A',
      role: 'Field Engineer',
      supervisor_id: ''
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Form Validation
    if (!formData.full_name.trim()) {
      toast.error('Full Name is required');
      return;
    }
    if (!formData.id_number.trim()) {
      toast.error('ID Number is required');
      return;
    }
    if (!formData.username.trim()) {
      toast.error('Username is required');
      return;
    }
    if (!editingUser && !formData.password.trim()) {
      toast.error('Initial Password is required for new users');
      return;
    }
    if (formData.password && formData.password.length < 6) {
      toast.error('Password must be at least 6 characters long');
      return;
    }
    if (!formData.role) {
      toast.error('Designation (Role) is required');
      return;
    }
    if (!formData.base_office.trim()) {
      toast.error('Base Office is required');
      return;
    }
    if (!formData.division.trim()) {
      toast.error('Division is required');
      return;
    }
    if (formData.role === 'Senior Field Engineer' && formData.district.length === 0) {
      toast.error('Please select at least one district for Senior Field Engineer');
      return;
    }
    if (formData.role === 'Field Engineer' && !formData.supervisor_id) {
      toast.error('Please assign a supervisor for Field Engineer');
      return;
    }

    const url = editingUser ? `/api/users/${editingUser.id}` : '/api/users';
    const method = editingUser ? 'PUT' : 'POST';
    
    // If editing and password is empty, don't send it
    const payload = { ...formData };
    if (editingUser && !payload.password) {
      delete (payload as any).password;
    }

    const response = await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (response.ok) {
      toast.success(editingUser ? 'User updated successfully' : 'User created successfully');
      resetForm();
      fetchUsers();
    } else {
      const data = await response.json();
      toast.error(data.message || `Failed to ${editingUser ? 'update' : 'create'} user`);
    }
  };

  const handleToggleStatus = async (id: number, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
    const response = await fetch(`/api/users/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    });

    if (response.ok) {
      toast.success(`User ${newStatus}`);
      fetchUsers();
    }
  };

  const handleDelete = (id: number) => {
    setUserToDelete(id);
  };

  const confirmDelete = async () => {
    if (!userToDelete) return;

    const promise = fetch(`/api/users/${userToDelete}`, {
      method: 'DELETE'
    }).then(async (res) => {
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.message || 'Failed to delete user');
      }
      return res;
    });

    toast.promise(promise, {
      loading: 'Deleting user...',
      success: () => {
        fetchUsers();
        setUserToDelete(null);
        return 'User deleted successfully';
      },
      error: (err) => {
        setUserToDelete(null);
        return err.message;
      }
    });
  };

  const filteredUsers = users.filter(u => {
    const matchesSearch = (u.full_name?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (u.username?.toLowerCase() || '').includes(searchTerm.toLowerCase()) ||
      (Array.isArray(u.district) ? u.district.join(', ').toLowerCase() : (u.district || '').toLowerCase()).includes(searchTerm.toLowerCase());
    
    const matchesRole = roleFilter === 'All' || u.role === roleFilter;
    const matchesStatus = statusFilter === 'All' || u.status === statusFilter;
    const matchesDivision = divisionFilter === 'All' || u.division === divisionFilter;
    const matchesBaseOffice = baseOfficeFilter === 'All' || u.base_office === baseOfficeFilter;

    return matchesSearch && matchesRole && matchesStatus && matchesDivision && matchesBaseOffice;
  });

  const supervisors = users.filter(u => u.role === 'Senior Field Engineer' || u.role === 'System Administrator' || u.role === 'Administrator');
  const uniqueDivisions = Array.from(new Set(users.map(u => u.division).filter(d => d && d !== 'N/A')));
  const uniqueBaseOffices = Array.from(new Set(users.map(u => u.base_office).filter(b => b && b !== 'N/A')));

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black text-white tracking-tight">User Management</h1>
          <p className="text-slate-400 text-sm mt-1">Manage system access, designations, and personnel assignments.</p>
        </div>
        
        <button 
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 rounded-xl text-sm font-medium text-white hover:bg-blue-500 shadow-lg shadow-blue-600/20 transition-all"
        >
          <UserPlus className="w-4 h-4" />
          Add New User
        </button>
      </div>

      <div className="bg-[#001a33] border border-white/5 rounded-3xl overflow-hidden shadow-2xl">
        <div className="p-6 border-b border-white/5 bg-white/[0.01] flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input 
              type="text" 
              placeholder="Search users by name, username or district..." 
              className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 pl-12 pr-4 text-sm text-white focus:outline-none focus:border-blue-500/50 transition-all placeholder:text-slate-600"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex gap-4">
            <div className="relative min-w-[160px]">
              <select 
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 px-4 pr-10 text-sm text-white focus:outline-none focus:border-blue-500/50 transition-all appearance-none cursor-pointer"
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
              >
                <option value="All" className="bg-[#001a33]">All Roles</option>
                <option value="Field Engineer" className="bg-[#001a33]">Field Engineer</option>
                <option value="Senior Field Engineer" className="bg-[#001a33]">Senior Field Engineer</option>
                <option value="System Administrator" className="bg-[#001a33]">System Administrator</option>
                <option value="Administrator" className="bg-[#001a33]">Administrator</option>
              </select>
              <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
            </div>
            <div className="relative min-w-[140px]">
              <select 
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 px-4 pr-10 text-sm text-white focus:outline-none focus:border-blue-500/50 transition-all appearance-none cursor-pointer"
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
              >
                <option value="All" className="bg-[#001a33]">All Statuses</option>
                <option value="active" className="bg-[#001a33]">Active</option>
                <option value="inactive" className="bg-[#001a33]">Inactive</option>
              </select>
              <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
            </div>

            <div className="relative min-w-[160px]">
              <select 
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 px-4 pr-10 text-sm text-white focus:outline-none focus:border-blue-500/50 transition-all appearance-none cursor-pointer"
                value={divisionFilter}
                onChange={(e) => setDivisionFilter(e.target.value)}
              >
                <option value="All" className="bg-[#001a33]">All Divisions</option>
                {uniqueDivisions.map(div => (
                  <option key={div} value={div} className="bg-[#001a33]">{div}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
            </div>

            <div className="relative min-w-[160px]">
              <select 
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-3 px-4 pr-10 text-sm text-white focus:outline-none focus:border-blue-500/50 transition-all appearance-none cursor-pointer"
                value={baseOfficeFilter}
                onChange={(e) => setBaseOfficeFilter(e.target.value)}
              >
                <option value="All" className="bg-[#001a33]">All Offices</option>
                {uniqueBaseOffices.map(office => (
                  <option key={office} value={office} className="bg-[#001a33]">{office}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 pointer-events-none" />
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          {selectedUsers.length > 0 && (
            <div className="bg-blue-600/20 border-b border-blue-500/30 px-6 py-3 flex items-center justify-between">
              <span className="text-sm font-medium text-blue-400">
                {selectedUsers.length} user{selectedUsers.length !== 1 ? 's' : ''} selected
              </span>
              <div className="flex gap-2">
                <button 
                  onClick={() => handleBulkAction('activate')}
                  className="px-3 py-1.5 bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors"
                >
                  Activate
                </button>
                <button 
                  onClick={() => handleBulkAction('deactivate')}
                  className="px-3 py-1.5 bg-amber-500/20 text-amber-400 hover:bg-amber-500/30 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors"
                >
                  Deactivate
                </button>
                <button 
                  onClick={() => handleBulkAction('delete')}
                  className="px-3 py-1.5 bg-rose-500/20 text-rose-400 hover:bg-rose-500/30 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors"
                >
                  Delete
                </button>
              </div>
            </div>
          )}
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-white/[0.02] text-slate-500 text-[10px] uppercase tracking-widest font-bold">
                <th className="px-6 py-4 w-12">
                  <div className="relative flex items-center">
                    <input 
                      type="checkbox" 
                      checked={filteredUsers.length > 0 && selectedUsers.length === filteredUsers.length}
                      onChange={toggleSelectAll}
                      className="peer h-4 w-4 cursor-pointer appearance-none rounded border border-white/20 bg-white/5 transition-all checked:bg-blue-600 checked:border-blue-600"
                    />
                    <CheckCircle2 className="absolute h-3 w-3 text-white opacity-0 peer-checked:opacity-100 left-0.5 pointer-events-none transition-opacity" />
                  </div>
                </th>
                <th className="px-6 py-4">User Details</th>
                <th className="px-6 py-4">ID Number</th>
                <th className="px-6 py-4">Username</th>
                <th className="px-6 py-4">Designation</th>
                <th className="px-6 py-4">Base Office</th>
                <th className="px-6 py-4">Division</th>
                <th className="px-6 py-4">District</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {loading ? (
                <tr><td colSpan={10} className="px-6 py-8 text-center text-slate-500">Loading users...</td></tr>
              ) : filteredUsers.length === 0 ? (
                <tr><td colSpan={10} className="px-6 py-8 text-center text-slate-500">No users found.</td></tr>
              ) : filteredUsers.map((u) => (
                <tr key={u.id} className={`hover:bg-white/[0.02] transition-all group border-b border-white/[0.02] last:border-0 ${selectedUsers.includes(u.id) ? 'bg-blue-500/5' : ''}`}>
                  <td className="px-6 py-4">
                    <div className="relative flex items-center">
                      <input 
                        type="checkbox" 
                        checked={selectedUsers.includes(u.id)}
                        onChange={() => toggleSelectUser(u.id, u.role)}
                        disabled={u.role === 'Administrator' && user.role !== 'Administrator'}
                        className="peer h-4 w-4 cursor-pointer appearance-none rounded border border-white/20 bg-white/5 transition-all checked:bg-blue-600 checked:border-blue-600 disabled:opacity-50 disabled:cursor-not-allowed"
                      />
                      <CheckCircle2 className="absolute h-3 w-3 text-white opacity-0 peer-checked:opacity-100 left-0.5 pointer-events-none transition-opacity" />
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <img 
                        src={u.avatar_url || `https://ui-avatars.com/api/?name=${u.full_name}&background=0284c7&color=fff&size=128`}
                        alt="Avatar"
                        className="w-10 h-10 rounded-xl object-cover"
                      />
                      <div>
                        <p className="text-sm font-bold text-white group-hover:text-blue-400 transition-colors">{u.full_name}</p>
                        {u.supervisor_name && (
                          <p className="text-[10px] text-slate-500 mt-0.5">Sup: {u.supervisor_name}</p>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm text-slate-300 font-mono">{u.id_number}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm text-slate-300 font-mono">{u.username}</p>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2 text-xs text-white font-medium">
                      <Shield className={`w-3.5 h-3.5 ${u.role === 'System Administrator' || u.role === 'Network Administrator' || u.role === 'Director' ? 'text-rose-400' : u.role === 'Senior Field Engineer' ? 'text-amber-400' : 'text-blue-400'}`} />
                      <span className="capitalize">{u.role}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm text-slate-300">{u.base_office || 'N/A'}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm text-slate-300">{u.division || 'N/A'}</p>
                  </td>
                  <td className="px-6 py-4">
                    <p className="text-sm text-slate-300">{Array.isArray(u.district) ? u.district.join(', ') : (u.district || 'N/A')}</p>
                  </td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest ${
                      u.status === 'active' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                    }`}>
                      <div className={`w-1.5 h-1.5 rounded-full ${u.status === 'active' ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                      {u.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-1">
                      {!(user.role !== 'Administrator' && u.role === 'Administrator') && (
                        <>
                          <button 
                            onClick={() => handleToggleStatus(u.id, u.status)}
                            className={`p-1.5 rounded-lg transition-all ${u.status === 'active' ? 'text-rose-400 hover:bg-rose-500/10' : 'text-emerald-400 hover:bg-emerald-500/10'}`}
                            title={u.status === 'active' ? 'Deactivate' : 'Activate'}
                          >
                            {u.status === 'active' ? <XCircle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
                          </button>
                          <button 
                            onClick={() => handleEdit(u)}
                            className="p-1.5 text-slate-500 hover:text-white transition-all"
                            title="Edit User"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDelete(u.id)}
                            className="p-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-all"
                            title="Delete User"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </>
                      )}
                      <button 
                        onClick={() => setViewingUser(u)}
                        className="p-1.5 text-slate-500 hover:text-white transition-all"
                        title="View User"
                      >
                        <Users className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <AnimatePresence>
        {showForm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={resetForm}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-[#001a33] border border-white/10 rounded-3xl w-full max-w-3xl max-h-[95vh] flex flex-col overflow-hidden relative z-10 shadow-2xl"
            >
              <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/[0.02] shrink-0">
                <div>
                  <h2 className="text-xl font-bold text-white">{editingUser ? 'Edit User Profile' : 'Create New User Account'}</h2>
                  <p className="text-xs text-slate-500 mt-1">Fill in the details below to {editingUser ? 'update the' : 'register a new'} user in the system.</p>
                </div>
                <button onClick={resetForm} className="p-2 text-slate-500 hover:text-white hover:bg-white/5 rounded-full transition-all">
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto custom-scrollbar p-8">
                <form id="user-form" onSubmit={handleSubmit} className="space-y-8">
                  <section>
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-400 mb-6 flex items-center gap-2">
                      <div className="w-1 h-1 rounded-full bg-blue-400" />
                      Personal Information
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Full Name</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. John Doe"
                          className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-blue-500 transition-all placeholder:text-slate-700"
                          value={formData.full_name || ''}
                          onChange={(e) => setFormData({...formData, full_name: e.target.value})}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">ID Number</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. EMP-001"
                          className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white font-mono focus:outline-none focus:border-blue-500 transition-all placeholder:text-slate-700"
                          value={formData.id_number || ''}
                          onChange={(e) => setFormData({...formData, id_number: e.target.value})}
                        />
                      </div>
                    </div>
                  </section>

                  <section>
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-400 mb-6 flex items-center gap-2">
                      <div className="w-1 h-1 rounded-full bg-blue-400" />
                      Account Credentials
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Username</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. jdoe"
                          className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white font-mono focus:outline-none focus:border-blue-500 transition-all placeholder:text-slate-700"
                          value={formData.username || ''}
                          onChange={(e) => setFormData({...formData, username: e.target.value})}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">{editingUser ? 'New Password (Optional)' : 'Initial Password'}</label>
                        <input 
                          type="password" 
                          required={!editingUser}
                          placeholder="••••••••"
                          className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-blue-500 transition-all placeholder:text-slate-700"
                          value={formData.password || ''}
                          onChange={(e) => setFormData({...formData, password: e.target.value})}
                        />
                      </div>
                    </div>
                  </section>

                  <section>
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-400 mb-6 flex items-center gap-2">
                      <div className="w-1 h-1 rounded-full bg-blue-400" />
                      Organizational Details
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Designation</label>
                        <div className="relative">
                          <select 
                            className="w-full bg-blue-500/10 border border-blue-400/30 rounded-xl py-3 px-4 pr-10 text-white focus:outline-none focus:border-blue-500 transition-all appearance-none cursor-pointer shadow-[0_0_15px_rgba(59,130,246,0.05)]"
                            value={formData.role || ''}
                            onChange={(e) => setFormData({...formData, role: e.target.value as any})}
                          >
                            <option value="Field Engineer" className="bg-[#001a33]">Field Engineer (Staff)</option>
                            <option value="Senior Field Engineer" className="bg-[#001a33]">Senior Field Engineer (Supervisor)</option>
                            <option value="System Administrator" className="bg-[#001a33]">System Administrator (Manager)</option>
                            {user.role === 'Administrator' && (
                              <option value="Administrator" className="bg-[#001a33]">Administrator (Controls Everything)</option>
                            )}
                          </select>
                          <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-400 pointer-events-none" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Base Office</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. HQ Office"
                          className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-blue-500 transition-all placeholder:text-slate-700"
                          value={formData.base_office || ''}
                          onChange={(e) => setFormData({...formData, base_office: e.target.value})}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Division</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. Engineering"
                          className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-blue-500 transition-all placeholder:text-slate-700"
                          value={formData.division || ''}
                          onChange={(e) => setFormData({...formData, division: e.target.value})}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Assign Supervisor</label>
                        <div className="relative">
                          <select 
                            className="w-full bg-blue-500/10 border border-blue-400/30 rounded-xl py-3 px-4 pr-10 text-white focus:outline-none focus:border-blue-500 transition-all appearance-none cursor-pointer shadow-[0_0_15px_rgba(59,130,246,0.05)]"
                            value={formData.supervisor_id || ''}
                            onChange={(e) => setFormData({...formData, supervisor_id: e.target.value})}
                            required={formData.role === 'Field Engineer'}
                          >
                            <option value="" className="bg-[#001a33]">None Assigned</option>
                            {supervisors.map(s => (
                              <option key={s.id} value={s.id} className="bg-[#001a33]">{s.full_name} ({s.role})</option>
                            ))}
                          </select>
                          <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-blue-400 pointer-events-none" />
                        </div>
                      </div>
                    </div>
                  </section>

                  <section>
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-400 mb-6 flex items-center gap-2">
                      <div className="w-1 h-1 rounded-full bg-blue-400" />
                      District Assignment
                    </h3>
                    <div className="space-y-2">
                      {formData.role === 'Senior Field Engineer' ? (
                        <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-6">
                          <p className="text-[10px] text-slate-500 mb-4 uppercase tracking-widest font-bold">Select multiple districts for supervisor role:</p>
                          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                            {ALL_DISTRICTS.map(dist => (
                              <label key={dist} className="flex items-center gap-3 text-xs text-slate-300 cursor-pointer group hover:text-white transition-colors">
                                <div className="relative flex items-center">
                                  <input 
                                    type="checkbox" 
                                    checked={formData.district.includes(dist)}
                                    onChange={(e) => {
                                      const newDistricts = e.target.checked 
                                        ? [...formData.district, dist] 
                                        : formData.district.filter(d => d !== dist);
                                      setFormData({...formData, district: newDistricts});
                                    }}
                                    className="peer h-5 w-5 cursor-pointer appearance-none rounded-md border border-white/20 bg-white/5 transition-all checked:bg-blue-600 checked:border-blue-600"
                                  />
                                  <CheckCircle2 className="absolute h-3.5 w-3.5 text-white opacity-0 peer-checked:opacity-100 left-0.5 pointer-events-none transition-opacity" />
                                </div>
                                {dist}
                              </label>
                            ))}
                          </div>
                        </div>
                      ) : (
                        <div className="relative">
                          <select 
                            className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 pr-10 text-white focus:outline-none focus:border-blue-500 transition-all appearance-none cursor-pointer"
                            value={Array.isArray(formData.district) ? formData.district[0] || 'N/A' : formData.district}
                            onChange={(e) => setFormData({...formData, district: [e.target.value]})}
                          >
                            <option value="N/A" className="bg-[#001a33]">N/A</option>
                            {ALL_DISTRICTS.map(dist => (
                              <option key={dist} value={dist} className="bg-[#001a33]">{dist}</option>
                            ))}
                          </select>
                          <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 pointer-events-none" />
                        </div>
                      )}
                    </div>
                  </section>
                </form>
              </div>

              <div className="p-6 border-t border-white/5 bg-white/[0.02] flex gap-4 shrink-0">
                <button 
                  type="button"
                  onClick={resetForm}
                  className="flex-1 py-3 rounded-xl border border-white/10 text-sm font-medium text-slate-400 hover:bg-white/5 transition-all"
                >
                  Cancel
                </button>
                <button 
                  form="user-form"
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-blue-600 text-sm font-medium text-white hover:bg-blue-500 shadow-lg shadow-blue-600/20 transition-all"
                >
                  {editingUser ? 'Save Changes' : 'Create Account'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {userToDelete && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setUserToDelete(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-[#001a33] border border-white/10 rounded-2xl w-full max-w-md overflow-hidden relative z-10 shadow-2xl p-6"
            >
              <div className="flex items-center gap-4 text-rose-400 mb-4">
                <div className="w-12 h-12 rounded-full bg-rose-500/10 flex items-center justify-center">
                  <Trash2 className="w-6 h-6" />
                </div>
                <h2 className="text-xl font-bold text-white">Delete User</h2>
              </div>
              
              <p className="text-slate-300 mb-8">
                Are you sure you want to delete this user? This action cannot be undone and will remove all associated data.
              </p>

              <div className="flex gap-4">
                <button 
                  onClick={() => setUserToDelete(null)}
                  className="flex-1 py-3 rounded-xl border border-white/10 text-sm font-medium text-slate-400 hover:bg-white/5 transition-all"
                >
                  Cancel
                </button>
                <button 
                  onClick={confirmDelete}
                  className="flex-1 py-3 rounded-xl bg-rose-600 text-sm font-medium text-white hover:bg-rose-500 shadow-lg shadow-rose-600/20 transition-all"
                >
                  Delete User
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {viewingUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setViewingUser(null)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="bg-[#001a33] border border-white/10 rounded-2xl w-full max-w-2xl overflow-hidden relative z-10 shadow-2xl"
            >
              <div className="p-6 border-b border-white/5 flex items-center justify-between bg-white/[0.02]">
                <h2 className="text-xl font-bold text-white">User Details</h2>
                <button onClick={() => setViewingUser(null)} className="text-slate-500 hover:text-white transition-all">
                  <X className="w-6 h-6" />
                </button>
              </div>
              
              <div className="p-8">
                <div className="grid grid-cols-3 gap-6">
                  <div className="col-span-2 space-y-6">
                    <div className="grid grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Full Name</label>
                        <p className="text-white">{viewingUser.full_name}</p>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">ID Number</label>
                        <p className="text-white font-mono">{viewingUser.id_number}</p>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Username</label>
                        <p className="text-white font-mono">{viewingUser.username}</p>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Designation</label>
                        <p className="text-white capitalize">{viewingUser.role}</p>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Base Office</label>
                        <p className="text-white">{viewingUser.base_office || 'N/A'}</p>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Division</label>
                        <p className="text-white">{viewingUser.division || 'N/A'}</p>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">District</label>
                        <p className="text-white">{Array.isArray(viewingUser.district) ? viewingUser.district.join(', ') : (viewingUser.district || 'N/A')}</p>
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500 uppercase tracking-widest">Supervisor</label>
                        <p className="text-white">{viewingUser.supervisor_name || 'N/A'}</p>
                      </div>
                    </div>
                  </div>
                  <div className="col-span-1 flex flex-col justify-end items-start space-y-4">
                    <img 
                      src={viewingUser.avatar_url || `https://ui-avatars.com/api/?name=${viewingUser.full_name}&background=0284c7&color=fff&size=128`}
                      alt="Avatar"
                      className="w-24 h-24 rounded-full object-cover border-4 border-blue-500/50 shadow-lg"
                    />
                    <div className="bg-white p-2 rounded-lg">
                      <QRCode value={`${viewingUser.id_number} - ${viewingUser.full_name}`} size={96} />
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
